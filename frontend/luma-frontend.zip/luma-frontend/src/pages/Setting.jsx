import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useTheme } from '../context/ThemeContext'
import { useLayoutTemplate } from '../context/LayoutContext'

const SAMPLERS = ['DPM++ 2M Karras', 'Euler a', 'Euler']
const SIZES = [512, 768, 1024]
const STORAGE_KEY = 'luma_settings'

const DEFAULT_SETTINGS = {
  defaultModel: '',
  defaultWidth: 512,
  defaultHeight: 512,
  defaultSteps: 20,
  defaultCfgScale: 7,
  defaultSampler: 'DPM++ 2M Karras',
}

export default function Setting() {
  const { logout } = useAuth()
  const { themeId, setThemeId, themes } = useTheme()
  const { templateId, setTemplateId, templates } = useLayoutTemplate()
  const [settings, setSettings] = useState(DEFAULT_SETTINGS)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) setSettings({ ...DEFAULT_SETTINGS, ...JSON.parse(raw) })
  }, [])

  function update(key, value) {
    setSettings((s) => ({ ...s, [key]: value }))
    setSaved(false)
  }

  function handleSave(e) {
    e.preventDefault()
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))
    setSaved(true)
    setTimeout(() => setSaved(false), 1800)
  }

  return (
    <div>
      <div className="page-header">
        <h1>Setting</h1>
        <p>Appearance is applied immediately. Generation defaults are stored locally in this browser.</p>
      </div>

      {/* ===== Appearance ===== */}
      <div className="card" style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 700, marginBottom: 14 }}>Appearance</div>
        <div className={`theme-grid ${templateId === 'soft' ? 'theme-grid-disabled' : ''}`}>
          {themes.map((t) => (
            <button
              key={t.id}
              type="button"
              disabled={templateId === 'soft'}
              className={`theme-swatch ${t.id === themeId ? 'selected' : ''}`}
              onClick={() => setThemeId(t.id)}
              style={{ borderColor: t.id === themeId ? t.colors.accent1 : undefined }}
            >
              <div className="theme-swatch-preview" style={{ background: t.colors.bg, borderColor: t.colors.border }}>
                <div className="theme-swatch-bar" style={{ background: t.colors.gradient }} />
                <div className="theme-swatch-card" style={{ background: t.colors.surfaceSolid, borderColor: t.colors.border }} />
                {t.id === themeId && (
                  <div className="theme-swatch-check" style={{ background: t.colors.accent1 }}>✓</div>
                )}
              </div>
              <div className="theme-swatch-label">{t.label}</div>
            </button>
          ))}
        </div>
        {templateId === 'soft' && (
          <p className="setting-hint">Soft ships with its own fixed palette — switch back to Classic to pick a theme.</p>
        )}

        <div className="setting-subgroup">
          <div className="setting-subgroup-title" id="layout-label">Layout</div>
          <div className="template-grid" role="radiogroup" aria-labelledby="layout-label">
            {templates.map((t) => (
              <button
                key={t.id}
                type="button"
                role="radio"
                aria-checked={t.id === templateId}
                className={`template-option ${t.id === templateId ? 'selected' : ''}`}
                onClick={() => setTemplateId(t.id)}
              >
                <span className={`template-preview template-preview-${t.id}`} aria-hidden="true">
                  <span className="template-preview-side" />
                  <span className="template-preview-body">
                    <span className="template-preview-line" />
                    <span className="template-preview-grid">
                      <i /><i /><i />
                    </span>
                  </span>
                </span>
                <span className="template-option-text">
                  <span className="template-option-label">{t.label}</span>
                  <span className="template-option-desc">{t.description}</span>
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ===== Generation Defaults ===== */}
      <form onSubmit={handleSave} className="card" style={{ marginBottom: 20 }}>
        <div style={{ fontWeight: 700, marginBottom: 14 }}>Generation Defaults</div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="defaultWidth">Default Width</label>
            <select id="defaultWidth" value={settings.defaultWidth} onChange={(e) => update('defaultWidth', Number(e.target.value))}>
              {SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="defaultHeight">Default Height</label>
            <select id="defaultHeight" value={settings.defaultHeight} onChange={(e) => update('defaultHeight', Number(e.target.value))}>
              {SIZES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="field-row">
          <div className="field">
            <label htmlFor="defaultSteps">Default Steps</label>
            <input id="defaultSteps" type="number" min={1} max={50} value={settings.defaultSteps} onChange={(e) => update('defaultSteps', Number(e.target.value))} />
          </div>
          <div className="field">
            <label htmlFor="defaultCfgScale">Default CFG Scale</label>
            <input id="defaultCfgScale" type="number" min={1} max={20} step={0.5} value={settings.defaultCfgScale} onChange={(e) => update('defaultCfgScale', Number(e.target.value))} />
          </div>
        </div>
        <div className="field" style={{ maxWidth: 280 }}>
          <label htmlFor="defaultSampler">Default Sampler</label>
          <select id="defaultSampler" value={settings.defaultSampler} onChange={(e) => update('defaultSampler', e.target.value)}>
            {SAMPLERS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
        <div className="action-row">
          <button className="btn btn-primary" type="submit">{saved ? 'Saved ✓' : 'Save Defaults'}</button>
        </div>
      </form>

      {/* ===== Account ===== */}
      <div className="card">
        <div style={{ fontWeight: 700, marginBottom: 14 }}>Account</div>
        <button type="button" className="btn btn-danger" onClick={logout}>Logout</button>
      </div>
    </div>
  )
}